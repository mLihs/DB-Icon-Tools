{
	"icon-colors": [
	{
		"color":"default",
		"code": {
			"rgba":[0,0,0,1],
			"hex": "#000"
		}
	}
	]
}