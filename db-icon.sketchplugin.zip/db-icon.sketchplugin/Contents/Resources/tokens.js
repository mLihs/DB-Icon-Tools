{
	"color": {
		"icons": {
			"functional": {
				"default":{ "value" : "#282D37"},
				"light":{"value" : "#646973"},
				"lighter":{"value" : "#878C96"},
				"white":{"value" : "#fffff"},
				"brand":{"value" : "#ec0016"},
				"warning":{"value" : "#F75F00"},
				"positive":{"value" : "#508B1B"}
			},
			"illustrative": {
				"pulse":{ "value" : "#ec0016"},
				"base":{"value" : "#282D37"}
			}
		}
	}
}