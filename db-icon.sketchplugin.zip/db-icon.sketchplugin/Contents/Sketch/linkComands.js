var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/linkComands.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/globalfunctions.js":
/*!********************************!*\
  !*** ./src/globalfunctions.js ***!
  \********************************/
/*! exports provided: saveToFile, getPluginPath, documentName, setFocusOnDocuments, createLink, createNiceHTMLLink, createNiceHTMLName, checkCollusion, drawErrorRegion */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "saveToFile", function() { return saveToFile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPluginPath", function() { return getPluginPath; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "documentName", function() { return documentName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setFocusOnDocuments", function() { return setFocusOnDocuments; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createLink", function() { return createLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createNiceHTMLLink", function() { return createNiceHTMLLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createNiceHTMLName", function() { return createNiceHTMLName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkCollusion", function() { return checkCollusion; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "drawErrorRegion", function() { return drawErrorRegion; });
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);

var document = sketch__WEBPACK_IMPORTED_MODULE_0___default.a.getSelectedDocument();
var layerStyles = document.sharedLayerStyles;

var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui");

var Shape = __webpack_require__(/*! sketch/dom */ "sketch/dom").Shape;

var Style = __webpack_require__(/*! sketch/dom */ "sketch/dom").Style;

var FILETYPE = 'html';
var LINKINPUT = "sketch://plugin/com.atomatic.icon-quality-tools/";
var LAYERSHOWFUNCTION = "element.show";
function saveToFile(_ref) {
  var filenamePrefix = _ref.filenamePrefix,
      string = _ref.content,
      fileType = _ref.fileType;
  // Configuring save panel
  var savePanel = NSSavePanel.savePanel();
  savePanel.allowedFileTypes = ["*"];
  savePanel.nameFieldStringValue = "".concat(filenamePrefix); // Launching alert

  var result = savePanel.runModal();

  if (result == NSFileHandlingPanelOKButton) {
    var path = savePanel.URL().path();
    var success = string.writeToFile_atomically_encoding_error(path, true, NSUTF8StringEncoding, null);
    var alert;

    if (success) {
      /* alert = createAlert({
         text: 'The ' + FILETYPE.toUpperCase() + '-file is successfully saved to:\n `' + path + '`',
         buttons: ['OK'],
       });*/
      //alert("Shared Color Palette JSON Exported!", "Styls Exprtet");
    } else {
      /* alert = createAlert({
         text: `The file could not be saved.`,
         buttons: ['OK'],
       });*/
    } //alert("Shared Color Palette JSON Exported!", "Styls Not Exprtet");
    //alert.runModal();

  }
}
function getPluginPath(context) {
  var path = context.scriptPath.split('/');
  path.splice(-3, 3);
  return path.join('/');
}
function documentName(context) {
  if (context.document.fileURL() == null) {
    return "unsaved_Doument";
  } else {
    return context.document.fileURL().path().replace(/\.sketch$/, '');
  }
}
function setFocusOnDocuments(neededDocument) {
  var openDocuments = sketch__WEBPACK_IMPORTED_MODULE_0___default.a.getDocuments();
  var docExsits = false;
  openDocuments.forEach(function (x) {
    var name = x.path;

    if (name) {
      var fileName = decodeURIComponent(name);
      fileName = fileName.match(/(?:.+\/)(.+)/)[1];
      fileName = fileName.replace(/\.sketch$/, '');

      if (neededDocument == fileName) {
        x.sketchObject.window().makeKeyAndOrderFront(nil);
        docExsits = true;
      }
    }
  });
  return docExsits;
}
function createLink(uri, doc) {
  // encodeURIComponent(URI)
  return LINKINPUT + LAYERSHOWFUNCTION + "?msg=" + encodeURIComponent(uri) + "&doc=" + encodeURIComponent(doc);
}
function createNiceHTMLLink(niceName, link) {
  return '<a href="' + link + '">' + niceName + '</a>';
}
function createNiceHTMLName(name) {
  var lastName = name.split("/");
  lastName = lastName[lastName.length - 1];
  return "<td><span class='block'>" + lastName + "</span><span class='block smallText'>" + name + "</span></td>";
}
function checkCollusion(pointA, pointB, objFrame, objCollisionPrecision) {
  var objX1 = pointA.x * objFrame.width;
  var objY1 = pointA.y * objFrame.height;
  var objX2 = pointB.x * objFrame.width;
  var objY2 = pointB.y * objFrame.height;

  if (objX1 < objX2 + objCollisionPrecision && objX1 + objCollisionPrecision > objX2 && objY1 < objY2 + objCollisionPrecision && objCollisionPrecision + objY1 > objY2) {
    return true;
  } else {
    return false;
  }
}
function drawErrorRegion(pointA, pointB, objFrame, object, name) {
  var fillStyle = {
    "borders": [{
      color: '#FF00F7CC',
      fillType: Style.FillType.Color,
      thickness: 0.5
    }]
  };
  var absolutePosX = object.sketchObject.absoluteRect().x() - object.getParentArtboard().sketchObject.absoluteRect().x();
  var absolutePosY = object.sketchObject.absoluteRect().y() - object.getParentArtboard().sketchObject.absoluteRect().y();
  var newShape = sketch__WEBPACK_IMPORTED_MODULE_0___default.a.Shape;
  var errorPosX = pointA.x * objFrame.width + absolutePosX;
  var errorPosY = pointA.y * objFrame.height + absolutePosY;
  var errorDimension = 2;
  var mySquare = new newShape({
    name: name,
    parent: object.getParentArtboard(),
    frame: {
      x: errorPosX - 1,
      y: errorPosY - 1,
      width: errorDimension,
      height: errorDimension
    },
    style: fillStyle
  });
  mySquare.layers[0].points.forEach(function (radius) {
    radius.cornerRadius = errorDimension / 2;
  });
}

/***/ }),

/***/ "./src/linkComands.js":
/*!****************************!*\
  !*** ./src/linkComands.js ***!
  \****************************/
/*! exports provided: setSelection */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setSelection", function() { return setSelection; });
/* harmony import */ var _globalfunctions_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./globalfunctions.js */ "./src/globalfunctions.js");
//import sketch from 'sketch'


var sketch = __webpack_require__(/*! sketch/dom */ "sketch/dom");

var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui");

var document = sketch.getSelectedDocument();

function centerToLayer(obj) {
  //document.centerOnLayer(obj)
  MSDocument.currentDocument().eventHandlerManager().currentHandler().zoomToSelection();
}

function unselectAllLayer() {
  var selectedLayersObject = document.selectedLayers;
  var selectedLayersArray = selectedLayersObject.layers;
  selectedLayersArray.forEach(function (layer) {
    layer.selected = false;
  });
}

function focusOnLayer(id) {
  var layer = document.getLayerWithID(id);

  if (layer) {
    unselectAllLayer();
    layer.getParentPage().selected = true;
    layer.selected = true;
    centerToLayer(layer);
  }
}

var setSelection = function setSelection(context) {
  var query = context.actionContext.query;
  var theID = query.msg;
  var theDoc = query.doc;
  var docIsOpen = _globalfunctions_js__WEBPACK_IMPORTED_MODULE_0__["setFocusOnDocuments"](theDoc);

  if (docIsOpen) {
    focusOnLayer(theID);
  } else {
    UI.alert('Document not Open', 'Please open ' + theDoc + ' first.');
  }
};

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['setSelection'] = __skpm_run.bind(this, 'setSelection');
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=linkComands.js.map